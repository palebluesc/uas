package id.ac.amikom.github.ui.detail

class bebasss {
}