package id.ac.amikom.github.data.model

data class UserResponse (
    val items : ArrayList<User>
)