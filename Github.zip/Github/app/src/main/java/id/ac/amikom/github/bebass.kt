package id.ac.amikom.github

class bebass {
}