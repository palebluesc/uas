package id.febridk.githubuser.data.model

data class User(
    val login: String,
    val avatar_url: String
)
